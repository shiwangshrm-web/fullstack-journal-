import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import './index.css'
import { Provider } from "react-redux";
import App from "./App.jsx";
import store from "./app/store.jsx";

createRoot(document.getElementById("root")).render(
    <StrictMode>
        <Provider store={store} >
            <App />
        </Provider>
    </StrictMode>
);