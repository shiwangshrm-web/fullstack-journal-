import { useDispatch, useSelector } from "react-redux";
import { increment, decrement, reset,setValueBy} from "./app/counterSlice";
import "./App.css";

function App() {
    const count = useSelector((state) => state.count.value);
    const dispatch = useDispatch();

    return (
        <div>
            <h1>Redux Counter</h1>

            <h2>Count: {count}</h2>

            <button onClick={() => dispatch(increment())}>
                Increment
            </button>

            <button onClick={() => dispatch(decrement())}>
                Decrement
            </button>

            <button onClick={() => dispatch(setValueBy(5))}>
                Add 5
            </button>

            <button onClick={() => dispatch(reset())}>
                Reset
            </button>
        </div>
    );
}

export default App;