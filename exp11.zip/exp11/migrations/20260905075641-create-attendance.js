'use strict';

const { QueryInterface } = require('sequelize');
const student = require('../models/student');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Attendances', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      studentId: {
        type: Sequelize.INTEGER,
        references:{
          model:'student',
          key:'id'
        },
        onUpdate:'CASCADE',
        onDelete:'CASCADE'

      },
      courseId: {
        type: Sequelize.INTEGER,
        references:{
          model:'course',
          key:'id'
        },
        onUpdate:'CASCADE',
        onDelete:'CASCADE'
      },
      date: {
        type: Sequelize.DATE
      },
      status: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }

    });
    
    await queryInterface.addConstraints("Attendance",{
    fields:[student,course],
    type:"unique",
    name:"unique_student_course"
  })
  },
  

  
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Attendances');
  }
};