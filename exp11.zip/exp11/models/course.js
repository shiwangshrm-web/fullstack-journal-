'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Course extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Course.hasMany(models.Attendence,{foreignKey:"cousreID"})
      Course.belongsToMany(models.student,{
        foreignKey:"courseID",
        through:models.Enrollment,
        as:"courses"

      })
      // define association here
    }
  }
  Course.init({
    courseCode: DataTypes.STRING,
    courseName: DataTypes.STRING,
    credits: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Course',
  });
  return Course;
};