// // import StudentCard from "./Studentcard"
// // function Studentlist(){
// //     let ok= 0;
// //     return(
// //         <ul>
// //             <StudentCard></StudentCard>
// //              <StudentCard></StudentCard>
// //         </ul>
// //     )
// // }
// // export default Studentlist;

// import StudentCard from "./Studentcard";

// function StudentList() {
   
   
//     let count1=0;

//   let studentList = [];

//   studentList.push({
//     name: "Shiwang",
//     rollNo: 101,
//     course: "BCA",
//     attendance: 85
//   });

//   studentList.push({
//     name: "Rahul",
//     rollNo: 102,
//     course: "BCA",
//     attendance: 90
//   });

//   studentList.push({
//     name: "Aman",
//     rollNo: 103,
//     course: "BCA",
//     attendance: 78
//   });

//   return (
//     <div>
//       <h1>Student List</h1>
      

//       <p>Number of Students: {studentList.length}</p>

//       {studentList.map((student, i) => (
//         <StudentCard
//           key={i}
//           student={student}
//         />
//       ))}
//     </div>
//   );
// }


// export default StudentList;