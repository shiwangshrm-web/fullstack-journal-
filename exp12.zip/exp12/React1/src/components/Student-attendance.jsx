// function StudentAttendance() {
//   return (
//     <div>
//       <h2>Student Attendance</h2>

//       <p>Name: Shiwang</p>
//       <p>Roll No: 101</p>
//       <p>Attendance: 85%</p>
//       <p>Status: Present</p>
//     </div>
//   );
// }

// export default StudentAttendance;

// function StudentAttendance(props) {
//   return (
//     <div>
//       <h2>Attendance</h2>

//       <p>Student: {props.student.name}</p>
//       <p>Roll No: {props.student.rollNo}</p>
//       <p>Attendance: {props.student.attendance}%</p>

//       {props.student.attendance >= 75 ? (
//         <p>Eligible</p>
//       ) : (
//         <p>Not Eligible</p>
//       )}
//     </div>
//   );
// }

// export default StudentAttendance;