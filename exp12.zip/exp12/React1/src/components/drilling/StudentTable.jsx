import { useContext } from "react";
import ThemeContext from "../context/ThemeContext";
import StudentRow from "./StudentRow";

function StudentTable() {

    const { theme } = useContext(ThemeContext);

    return (
        <div
            style={{
                backgroundColor: theme === "light" ? "white" : "black",
                color: theme === "light" ? "black" : "white",
                padding: "20px"
            }}
        >

            <h2>Student Table</h2>

            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Roll No</th>
                        <th>State</th>
                    </tr>
                </thead>

                <tbody>
                    <StudentRow />
                </tbody>

            </table>

        </div>
    );
}

export default StudentTable;