import { useContext } from "react";
import ThemeContext from "../context/ThemeContext";

function StudentRow() {

    const { theme, setTheme } = useContext(ThemeContext);

    function changeTheme() {

        if (theme === "light") {
            setTheme("dark");
        } else {
            setTheme("light");
        }

    }

    return (
        <tr>

            <td>Shiwang</td>
            <td>101</td>
            <td>Goa</td>

            <td>
                <button onClick={changeTheme}>
                    Change Theme
                </button>
            </td>

        </tr>
    );
}

export default StudentRow;