// function StudentCard() {
//   return (
//     <div>
//       <h2>Student Card</h2>
//       <p>Name: Shiwang</p>
//       <p>Roll No: 101</p>
//       <p>Course: BCA</p>
//     </div>
//   );
// }

// export default StudentCard;