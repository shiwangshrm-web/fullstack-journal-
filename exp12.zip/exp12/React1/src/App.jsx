import { useState } from "react";
import StudentList from "./components/Studentlist";
import ThemeContext from "./components/context/ThemeContext";

function App() {

    const [theme, setTheme] = useState("light");

    return (
        <ThemeContext.Provider value={{ theme, setTheme }}>

            <div>
                <h1>Student Management System</h1>

                <StudentList />
            </div>

        </ThemeContext.Provider>
    );
}

export default App;