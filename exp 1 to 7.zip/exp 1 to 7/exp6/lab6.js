console.log("lab6") 
const express = require("express")

const app= express()

const studentrouter = require("./apiController/student/student")
const teacherrouter = require("./apiController/teacher/teacher")
const uiRouter = require("./ui/view");


app.use("/api/student", studentrouter);

app.use("api/teacher", teacherrouter);
app.use("/", uiRouter)


app.listen(2000,()=>{
    console.log("listning")
})

