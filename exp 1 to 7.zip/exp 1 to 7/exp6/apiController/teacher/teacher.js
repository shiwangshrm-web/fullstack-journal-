const express = require("express")
const teacherrouter= express.Router()

teacherrouter.get("/teacher/get",(req,res)=>{
    res.send("teacher get")
})
teacherrouter.post("/teacher/save",(req,res)=>{
    res.send("teacher save")
})
module.exports= teacherrouter