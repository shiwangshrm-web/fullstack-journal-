const express = require("express")
const studentrouter= express.Router()

studentrouter.get("/get",(req,res)=>{
    res.send("student get")
})
studentrouter.post("/post",(req,res)=>{
    res.send("student save")
})
module.exports= studentrouter