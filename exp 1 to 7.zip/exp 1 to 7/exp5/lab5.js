// console.log("lab5")
// const fs = require("fs")
// fs.appendFile("app.txt","\n fein",(err,data)=>{
//     console.log(data)
// })
// fs.readFile("app.txt","utf-8",(err,data)=>{
//   console.log(data)
// })
// fs.writeFile("app.txt","",(err,data)=>{
//     console.log(data)
// })
// const express = require("express")
// const app = new express()
// app.listen(8080,()=>{
  console.log("listening")
// })
// app.get("/hm",(req,res)=>{
//       const {id,name,role}=req.query; 
//      console.log(id,name,role)
//     res.send("ok bb")
// })
// // http://localhost:8080/?id=01
// // http://localhost:8080/?id=01&name=shiwang&role=student

// const fs = require("fs")
// const readstream = fs.createReadStream("largefile.txt",{
//     encoding: "utf-8",
//     highWaterMark: 100
// })
// readstream.emit()
// readstream.on("data",(data)=>{
//     console.log("<=======>")
//     console.log(data)
// })  
const fs = require("fs");
// const createWriteStream = fs.createWriteStream("tyNames.txt")
// createWriteStream.write("shiwang\n")
// createWriteStream.write("is a \n")
// createWriteStream.write("good guy\n")

// createWriteStream.close()
// const readStream = fs.createReadStream("largefile.txt","utf-8")
const writeStream = fs.createWriteStream("largefile.txt", "utf-8")
// readStream.pipe(writeStream)
process.stdin.pipe(writeStream)

process.stdin.on("data", (data) => {
    console.log("this is typed==>", data.toString())
})