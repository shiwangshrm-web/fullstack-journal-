

const { buyprosp, fillform, submitadm, verify,
     answerEntrance, admissionsucess } = 
     require("./admissionProcess.js")

function admit() {

    buyprosp()
    .then((data) => {
        console.log(1, data)
        return fillform()
    }).then((data) => {
        console.log(2,data)
        return submitadm()
    }).then((data) => {
        console.log(3, data)
        return verify()
    }).then((data) => {
        console.log(4, data)
        return answerEntrance()
    }).then((data) => {
        console.log(5, data)
        return admissionsucess()
    })
}

admit()


console.log(1)
setTimeout(()=>console.log(2), 0)

console.log(3)
console.log(4)