

const createpromise = (text,timer)=>{
    return new Promise((resolve,reject)=>{
        setTimeout(() => {
            resolve(text)
            
        }, timer);
    })
}

const buyprosp=()=>{
    return createpromise("bought prosp",100)
}
const fillform=()=>{
    return createpromise("form filled",1900)
}
const submitadm=()=>{
    return createpromise(" form submitted ",1300)
}
const verify=()=>{     
    return createpromise("verified",1000)
}
const answerEntrance=()=>{
    return createpromise("entrance answerd",0)
}
const admissionsucess=()=>{
    return createpromise("admission completed",1000)
}

module.exports= {
    buyprosp,
    fillform,
    submitadm,
    verify,
    answerEntrance,
    admissionsucess  
}