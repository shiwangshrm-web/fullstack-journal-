console.log("hi")
// const chkmrk=(marks)=>{
//     const promise= new Promise((resolve,reject)=>{
//         if(marks===100){
//             resolve("perfect")}
//         else if(marks>=90){
//             resolve("excellent")}
//         else if(marks>=70){
//             resolve("distiction")}
//         else if(marks>=50){
//             resolve(" very good")}
//         else if(marks>=33){
//             resolve("good")}
//         else{
//             reject("fail")
//         }
//     });
//     return promise;
    
// }
// chkmrk().then((data)=>{
//         console.log(data);

//     }).catch(err => console.log(err))


const chkmrk=(marks)=>{
    const promise= new Promise((resolve,reject)=>{
        if(marks===100){
            resolve("perfect")}
        else if(marks>=90){
            resolve("excellent")}
        else if(marks>=70){
            resolve("distiction")}
        else if(marks>=50){
            resolve(" very good")}
        else if(marks>=33){
            resolve("good")}
        else{
            reject("fail")
        }
    });
    return promise;
    
}
chkmrk().then((data)=>{
        console.log(data);

    }).catch(err => console.log(err))