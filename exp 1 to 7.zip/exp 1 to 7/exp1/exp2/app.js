const express= require('express');
//imports dependency
// now to crrate the object of express
const app= express();
app.get("/",(req,res)=>{
    console.log("/called");
    res.send("hello world")
 

})
app.get("/about",(req,res)=>{
    console.log("/called about");
    res.send("into about us")


})
app.listen(3000,()=>{
    console.log(" Runninng at port 3000")


})