const path= require("path")
module.exports={
    entry: "./app.js",
    output:{
        filename:"webpck.js",
        path : path.resolve(__dirname,"dist")
    },
    mode:"development"
};
