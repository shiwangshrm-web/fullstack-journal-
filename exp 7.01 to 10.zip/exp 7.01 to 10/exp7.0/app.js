console.log("hiiii")
// const cron = require("node-cron")
// const fs=require("fs")
// // cron.schedule("27 13 * * *", ()=>{


// //     console.log("function called at 1:15", new Date())
// // })

// cron.schedule("*/1 * * * *", ()=>{
//     fs.appendFile("./create.txt", "\n  created ", (err,data)=>{
//         console.log(data)
//         })
//     fs.readFile("./create.txt", "utf-8", (err,data)=>{
//     console.log(data)
//     })

//     console.log("function called at everymin", new Date())
// })



// cron.schedule("*/2 * * * *", ()=>{
//     fs.unlink("./create.txt",  (err)=>{
//         console.log(err)
//         })
    
//     console.log("function called at every  2 min to DELETE", new Date())
// })