const {Student}=require("../models");
const createStudent=async (req,res)=>{
    try{
        const student=await Student.create(req.body);
        res.status(201).json(student);

    }catch(e){
        console.log(e)
        res.status(500).json(e)
    }
}
const getStudent=async (req,res)=>{
 try{
        const student=await Student.findAll();
        res.status(201).json(student);

    }catch(e){
        console.log(e)
        res.status(500).json(e)
    }}
module.exports={
    createStudent,
    getStudent
}
