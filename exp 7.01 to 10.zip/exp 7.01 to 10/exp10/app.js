const express=require("express")
const student = require("./service/studentserv")
const app= express()
app.get("/gett",(req,res)=>{
    res.send("hello")
})
app.listen(8000,()=>{
    console.log("port running ")
})
app.post("/api/studentp",student.createStudent)
app.get("/api/student",student.createStudent)