import { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import StudentTable from "./components/drilling/StudentTable";
import ThemeContext from "./components/context/ThemeContext";

function Home() {
    return <h2>Home Page</h2>;
}

function Contacts() {
    return <h2>Contacts Page</h2>;
}

function Student() {
    return <StudentTable />;
}

function About() {
    return <h2>About Page</h2>;
}

function App() {

    const [theme, setTheme] = useState("light");

    return (
        <ThemeContext.Provider value={{ theme, setTheme }}>

            <div>
                <h1>Student Management System</h1>

                <BrowserRouter>

                    <nav>
                        <ul>
                            <li>
                                <a href="/">Home</a>
                            </li>
                            <li>
                                <a href="/contacts">Contacts</a>
                            </li>
                            <li>
                                <a href="/student">Student</a>
                            </li>
                            <li>
                                <a href="/about">About</a>
                            </li>
                        </ul>
                    </nav>

                    <Routes>
                        <Route path="/" element={<Home />} />
                        <Route path="/contacts" element={<Contacts />} />
                        <Route path="/student" element={<Student />} />
                        <Route path="/about" element={<About />} />
                    </Routes>

                </BrowserRouter>
            </div>

        </ThemeContext.Provider>
    );
}

export default App;